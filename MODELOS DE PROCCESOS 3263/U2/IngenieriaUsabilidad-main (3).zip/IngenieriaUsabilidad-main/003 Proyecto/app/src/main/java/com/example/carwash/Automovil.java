package com.example.carwash;

public class Automovil {/*Automovil*/
    private String tipoAutomovil;

    public Automovil(String tipoAutomovil) {
        this.tipoAutomovil = tipoAutomovil;
    }

    public String getTipoAutomovil() {
        return tipoAutomovil;
    }

    public void setTipoAutomovil(String tipoAutomovil) {
        this.tipoAutomovil = tipoAutomovil;
    }
}
