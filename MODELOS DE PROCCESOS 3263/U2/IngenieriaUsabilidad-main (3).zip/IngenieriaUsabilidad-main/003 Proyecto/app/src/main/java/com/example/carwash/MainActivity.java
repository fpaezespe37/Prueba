package com.example.carwash;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    List<Usuario> listUsuario;
    TextView textView;
    Usuario usuario;
    EditText correo, contraseña;
    Button btnIngresar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        correo = findViewById(R.id.edtEmail);
        contraseña = findViewById(R.id.edtContraseña);
        btnIngresar = findViewById(R.id.btnIngresar);
        textView = (TextView)findViewById(R.id.txtRegistrese);

        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Registrarse.class);
                startActivity(intent);
            }
        });

        btnIngresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String correo1 = listUsuario.get(1).getCorreo().toString();
                String contraseña1 = listUsuario.get(1).getContraseña().toString();

                if(correo.getText().toString().equals(correo1) && contraseña.getText().toString().equals(contraseña1)){
                    
                    Toast.makeText(MainActivity.this, "Correcto",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this, "Verifique usuario/contraseña",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
