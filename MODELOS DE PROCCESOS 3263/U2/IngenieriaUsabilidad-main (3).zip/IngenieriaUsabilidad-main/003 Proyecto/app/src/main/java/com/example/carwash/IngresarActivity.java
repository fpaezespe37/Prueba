package com.example.carwash;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class IngresarActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingresar);
    }
}