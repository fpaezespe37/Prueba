package com.example.carwash;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.List;

public class Registrarse extends AppCompatActivity {
    List<Usuario> listUsuario;
    TextView textView;
    Button button;
    Usuario usuario;
    EditText nombre,correo,contraseña;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrarse);
        nombre = (EditText)findViewById(R.id.edtNombreCompleto);
        correo = (EditText)findViewById(R.id.edtEmail);
        contraseña = (EditText)findViewById(R.id.edtContraseña);
        textView = (TextView)findViewById(R.id.txtIniciaSesion);
        button = (Button)findViewById(R.id.btnRegistrarse);

        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Registrarse.this, MainActivity.class);
                startActivity(intent);
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent btnIntent = new Intent(Registrarse.this,MainActivity.class);
                startActivity(btnIntent);
                usuario = new Usuario(nombre.getText().toString(),correo.getText().toString(),contraseña.getText().toString());
                listUsuario.add(usuario);
            }
        });
    }
}